<?php
define( 'DB_ADR',      'mysql-<user>.alwaysdata.net' );
define( 'DB_NAME',     'geoarcmap_db'                );
define( 'DB_USERNAME', '<user>'                      );
define( 'DB_PASSWORD', '<password>'                  );
?>